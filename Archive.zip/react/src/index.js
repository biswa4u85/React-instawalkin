import React from 'react';
import ReactDOM from 'react-dom';
import PartnerFrom from './PartnerForm';

ReactDOM.render(<PartnerFrom />, document.getElementById('root'));